﻿using EasySave.Utils;
using EasySave.ViewModels;
using System;
using System.IO;
using System.Linq;

namespace EasySaveConsole.Views
{
    class MenuConsoleView
    {
        private readonly MenuViewModel _viewModel;

        public MenuConsoleView(MenuViewModel viewModel)
        {
            _viewModel = viewModel;
            _Render();
        }

        /// <summary>
        /// Get the terminal logo of the app
        /// </summary>
        /// <returns>Terminal logo</returns>
        private string _WriteLogo()
        {
            return @"
      ::::::::::     :::      ::::::::  :::   :::             ::::::::      :::     :::     ::: :::::::::: 
     :+:          :+: :+:   :+:    :+: :+:   :+:            :+:    :+:   :+: :+:   :+:     :+: :+:         
    +:+         +:+   +:+  +:+         +:+ +:+             +:+         +:+   +:+  +:+     +:+ +:+          
   +#++:++#   +#++:++#++: +#++:++#++   +#++:              +#++:++#++ +#++:++#++: +#+     +:+ +#++:++#      
  +#+        +#+     +#+        +#+    +#+                      +#+ +#+     +#+  +#+   +#+  +#+            
 #+#        #+#     #+# #+#    #+#    #+#               #+#    #+# #+#     #+#   #+#+#+#   #+#             
########## ###     ###  ########     ###                ########  ###     ###     ###     ##########       


";
        }

        /// <summary>
        /// Run the task associated to the menu choice
        /// </summary>
        /// <param name="choice">Menu choice</param>
        private void _MenuChoice(int choice)
        {
            switch(choice) {
                case 1:
                    _MenuCreateBackup();
                    break;
                case 2:
                    _MenuDeleteBackup();
                    break;
                case 3:
                    _MenuSaveBackup();
                    break;
                case 4:
                    _ChangeLanguage();
                    break;
                case 5:
                    _ChangeType();
                    break;
                case 6:
                    _ChangeLogStrategy();
                    break;
                case 7:
                    Environment.Exit(0);
                    break;
            }

            Console.WriteLine(Localizer.GetString("ClickToReturnMenu"));
            Console.ReadLine();
            _Render();
        }

        private void _ChangeType()
        {
            if (_viewModel.Backups.Count == 0) Console.WriteLine(Localizer.GetString("NoBackupToChangeType"));
            else
            {
                Console.WriteLine(Localizer.GetString("WhichBackupToChangeType"));
                int num = ReadValue<int>();
                while(num >=  _viewModel.Backups.Count) 
                {
                    Console.WriteLine(Localizer.Format("IndexOutOfBoundsBackup", num));
                    num = ReadValue<int>();
                }

                Console.WriteLine(Localizer.GetString("WhichBackupType"));

                int type = ReadValue<int>();
                while(type != 1 && type != 2)
                {
                    Console.WriteLine(Localizer.Format("IndexOutOfBoundsType"), type);
                }

                (string backupName, string backupType) = _viewModel.ChangeType(num, type);
                Console.WriteLine(Localizer.Format("BackupChangedType", backupName, Localizer.GetString(backupType)));
            }
        }

        /// <summary>
        /// Change the language of the locale
        /// </summary>
        private void _ChangeLanguage()
        {
            Console.WriteLine(Localizer.GetString("WhichLanguage"));
            string availableLanguage = Localizer.GetString("AvailableLanguage");
            foreach (var lang in Localizer.GetLanguages())
            {
                availableLanguage += lang+System.Environment.NewLine;
            }
            Console.WriteLine(availableLanguage);
            string language = ReadValue<string>();
            while(!Localizer.GetLanguages().Contains(language))
            {
                language = ReadValue<string>();
            }
            _viewModel.ChangeLanguage(language);
        }

        private void _ChangeLogStrategy()
        {
            Console.WriteLine(Localizer.Format("WhichLogStrategy"));
            Console.WriteLine("JSON \nXML");
            string logStrategy = ReadValue<string>();
            while(logStrategy != "JSON" && logStrategy != "XML")
            {
                logStrategy = ReadValue<string>();
            }
            _viewModel.ChangeLogType(logStrategy);
        }

        /// <summary>
        /// Task of creating a backup by asking the Name, Source, Target, Type
        /// </summary>
        private void _MenuCreateBackup()
        {
            if (_viewModel.Backups.Count < 5)
            {
                Console.WriteLine(Localizer.GetString("InsertBackupName"));
                string backupName = ReadValue<string>();
                while (_viewModel.Backups.Where(strategy => strategy.Name == backupName).Any())
                {
                    Console.WriteLine(Localizer.Format("AlreadyUsedBackupName", backupName));
                    backupName = ReadValue<string>();
                }

                Console.WriteLine(Localizer.GetString("InsertSourceName"));
                string backupSourcePath = ReadValue<string>();
                while (!Directory.Exists(backupSourcePath) && !File.Exists(backupSourcePath))
                {
                    Console.WriteLine(Localizer.Format("FileOrDirectoryNotExist", backupSourcePath));
                    backupSourcePath = ReadValue<string>();
                }

                Console.WriteLine(Localizer.GetString("InsertTargetName"));
                string backupTargetPath = ReadValue<string>();
                while (!Directory.Exists(backupTargetPath) && !File.Exists(backupTargetPath))
                {
                    Console.WriteLine(Localizer.Format("FileOrDirectoryNotExist", backupTargetPath));
                    backupTargetPath = ReadValue<string>();
                }

                Console.WriteLine(Localizer.GetString("InsertTargetType"));
                int backupType = ReadValue<int>();
                while (backupType != 1 && backupType != 2)
                {
                    Console.WriteLine(Localizer.Format("TargetTypeNotValid", backupType));
                    backupType = ReadValue<int>();
                }
                _viewModel.CreateBackup(backupName, backupSourcePath, backupTargetPath, backupType);
            } 
            else
            {
                Console.WriteLine(Localizer.GetString("Already5Saves"));
            }
        }

        /// <summary>
        /// Task of deleting a backup by asking the index in the backup list
        /// </summary>
        private void _MenuDeleteBackup()
        {
            if (_viewModel.Backups.Count == 0) Console.WriteLine(Localizer.GetString("NoSaveToDelete"));
            else
            {
                Console.WriteLine(Localizer.GetString("WhichBackupToDelete"));

                int num = ReadValue<int>();
                string backupName = _viewModel.DeleteBackup(num);
                while(backupName == null)
                {
                    Console.WriteLine(Localizer.Format("IndexOutOfBoundsBackup", num));
                    num = ReadValue<int>();
                    backupName = _viewModel.DeleteBackup(num);
                }
                Console.WriteLine(Localizer.Format("DeletedSave", backupName));
            }
        }

        /// <summary>
        /// Task of saving a backup by asking the index in the backup list
        /// </summary>
        private void _MenuSaveBackup()
        {
            Console.WriteLine(Localizer.GetString("WhichBackupToSave"));
            string backupNums = ReadValue<string>();
            _viewModel.SaveBackups(Array.ConvertAll(backupNums.Split(';'), int.Parse));
            Console.WriteLine(Localizer.Format("BackupSave", backupNums));
        }

        /// <summary>
        /// Utils for the console to get a value typed of T. Usage: ReadValue<T>();
        /// </summary>
        /// <typeparam name="T">Type of the value</typeparam>
        /// <returns>Value of the type T</returns>
        public T ReadValue<T>()
        {
            T result = default;
            bool valid = false;
            while (!valid)
            {
                try
                {
                    result = (T)Convert.ChangeType(Console.ReadLine(), typeof(T));
                    valid = true;
                }
                catch
                {
                }
            }
            return result;
        }

        /// <summary>
        /// Render of the backup list
        /// </summary>
        /// <returns></returns>
        private string _BackupsRender()
        {
            string backupsRender = "";
            int index = 0;
            _viewModel.Backups.Select(strategy => backupsRender += Localizer.Format("RowBackupRender", index++, strategy.ToString()));
            return backupsRender;
        }

        /// <summary>
        /// Basic view rerendered after every task
        /// </summary>
        private void _Render()
        {
            string logo = _WriteLogo();
            string backupsRender = _BackupsRender();
            string render = Localizer.Format("MainMenuChoice", logo, backupsRender);

            Console.Clear();
            Console.WriteLine(render);
            _MenuChoice(ReadValue<int>());
        }


    }
}
