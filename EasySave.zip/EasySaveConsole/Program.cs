﻿using EasySave.ViewModels;
using EasySaveConsole.Views;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace EasySaveConsole
{
    internal class Program
    {
        static void Main(string[] args)
        {
            MenuViewModel viewModel = new MenuViewModel();
            MenuConsoleView _ = new MenuConsoleView(viewModel);
        }
    }
}
