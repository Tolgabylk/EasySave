﻿using System.Threading;
using System.Windows;

namespace EasySaveGraphic
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        private static bool isUnique;
        private static readonly Mutex _ = new Mutex(true, "Global/EasySave", out isUnique);

        protected override void OnStartup(StartupEventArgs e)
        {
            if(!isUnique)
            {
                MessageBox.Show("EasySave is already running");
                Application.Current.Shutdown();
            } 
            else
            {
                base.OnStartup(e);
            }
        }
    }
}
