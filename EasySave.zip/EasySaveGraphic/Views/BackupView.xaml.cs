﻿using EasySave.Models.Backups;
using EasySave.Utils;
using EasySave.ViewModels;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Threading;
using System.Windows;
using System.Windows.Controls;

namespace EasySaveGraphic.Views
{
    /// <summary>
    /// Interaction logic for Backup.xaml
    /// </summary>
    public partial class BackupView : Page
    {
        public ObservableCollection<Backup> Backups { get; set; }

        public MenuViewModel ViewModel;

        public BackupView(MenuViewModel viewModel) : this()
        {
            ViewModel = viewModel;
            Backups = ViewModel.Backups;
            LanguageUpdate();
        }

        public BackupView()
        {
            InitializeComponent();
            DataContext = this;
            LanguageUpdate();
        }

        private void LanguageUpdate()
        {
            BackupsTextBlock.Text = Localizer.GetString("Backups");
            CreateBackupTextBlock.Text = Localizer.GetString("CreateNewBackup");

        }

        private void PlayButton_Click(object sender, RoutedEventArgs e)
        {
            Button b = sender as Button;
            if (Backups[(int)b.Tag].State == "PAUSE")
            {
                ViewModel.ResumeBackup((int)b.Tag);
            }
            else
            {
                 Thread t = ViewModel.SaveBackup((int)b.Tag);
                if (t != null) t.Start();
                else MessageBox.Show(Localizer.GetString("Error"));
            }
        }

        private void PauseButton_Click(object sender, RoutedEventArgs e)
        {
            Button b = sender as Button;
            ViewModel.PauseBackup((int)b.Tag);
        }

        private void StopButton_Click(object sender, RoutedEventArgs e)
        {
            Button b = sender as Button;
            ViewModel.StopBackup((int)b.Tag);
        }

        private void EditButton_Click(object sender, RoutedEventArgs e)
        {
            Button b = sender as Button;
            OpenEditWorkWindow(Backups[(int)b.Tag]);
        }

        private void OpenEditWorkWindow(Backup backup)
        {
            BackupSettingsWindow backupSettingsWindow = new BackupSettingsWindow(backup, ViewModel);
            backupSettingsWindow.ShowDialog();
        }

        private void OpenCreateWorkWindow()
        {
            NewBackupWindow newBackupWindow = new NewBackupWindow(ViewModel);
            newBackupWindow.ShowDialog();
        }

        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            Button b = sender as Button;
            ViewModel.DeleteBackup((int)b.Tag);
        }

        private void CreateBackup_Click(object sender, RoutedEventArgs e)
        {
            OpenCreateWorkWindow();
            Backups = new ObservableCollection<Backup>(ViewModel.Backups);
        }

    }
}
