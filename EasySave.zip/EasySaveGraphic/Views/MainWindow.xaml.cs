﻿using EasySave.Models.Backups;
using EasySave.Utils;
using EasySave.ViewModels;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace EasySaveGraphic.Views
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public ObservableCollection<Backup> Backups;
        public MenuViewModel ViewModel;
        public MainWindow()
        {
            InitializeComponent();
            ViewModel = new MenuViewModel();
            Backups = ViewModel.Backups;
            LanguageUpdate();
        }

        private delegate void delegateLanguageUpdate();
        public void LanguageUpdate()
        {
            LabelBackups.Text = Localizer.GetString("Backups");
            LabelSettings.Text = Localizer.GetString("Settings");
            LabelLogs.Text = Localizer.GetString("Logs");
        }
        private void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            Frame.Navigate(new BackupView(ViewModel));
        }

        private void BackupButton_Click(object sender, RoutedEventArgs e)
        {
            Frame.Navigate(new BackupView(ViewModel));
            BackupButton.Background = (SolidColorBrush)new BrushConverter().ConvertFromString("#e0e0e0");
            SettingsButton.Background = (SolidColorBrush)new BrushConverter().ConvertFromString("#ffffff");
        }

        private void SettingsButton_Click(object sender, RoutedEventArgs e)
        {
            Frame.Navigate(new Settings(ViewModel, this));
            SettingsButton.Background = (SolidColorBrush)new BrushConverter().ConvertFromString("#e0e0e0");
            BackupButton.Background = (SolidColorBrush)new BrushConverter().ConvertFromString("#ffffff");

        }

        private void LogsButton_Click(object sender, RoutedEventArgs e)
        {
            string _documentDirectoryPath = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments)+"\\";
            string _DirectoryPath = @"EasySave";
            string _logDirectoryPath = @"EasySave\Logs";
            DirectoryUtils.IfNotExistCreateDirectory(_documentDirectoryPath + _DirectoryPath);
            DirectoryUtils.IfNotExistCreateDirectory(_documentDirectoryPath + _logDirectoryPath);

            Process process = new Process();
            process.StartInfo.FileName = "explorer.exe";
            process.StartInfo.Arguments = _documentDirectoryPath+_logDirectoryPath;
            process.Start();
        }

        private void Frame_Navigated(object sender, System.Windows.Navigation.NavigationEventArgs e)
        {

        }
    }
}
