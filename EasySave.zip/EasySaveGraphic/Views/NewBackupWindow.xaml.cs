﻿using EasySave.Models.Backups;
using EasySave.Utils;
using EasySave.ViewModels;
using Ookii.Dialogs.Wpf;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Net;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace EasySaveGraphic.Views
{
    /// <summary>
    /// Interaction logic for BackupSettingsWindow.xaml
    /// </summary>
    public partial class NewBackupWindow : Window
    {
        public MenuViewModel ViewModel;

        public NewBackupWindow(MenuViewModel viewModel) : this()
        {
            ViewModel = viewModel;
        }

        public NewBackupWindow()
        {
            InitializeComponent();
            LanguageUpdate();
        }


        private void LanguageUpdate()
        {
            NewBackupTextBlock.Text = Localizer.GetString("NewBackup");
            NameLabel.Content = Localizer.GetString("Name");
            SourceLabel.Content = Localizer.GetString("Source");
            DestinationLabel.Content = Localizer.GetString("Destination");
            TypeLabel.Content = Localizer.GetString("Type");
            TypeFull.Content = Localizer.GetString("BackupFull");
            TypeDifferential.Content = Localizer.GetString("BackupDifferential");
            CreateTextBlock.Text = Localizer.GetString("Create");
            GoBackTextblock.Text = Localizer.GetString("GoBack");

        }
        private string GetPathNew()
        {
            FolderBrowserDialog dialog = new FolderBrowserDialog();
            DialogResult result = dialog.ShowDialog();

            if (result == System.Windows.Forms.DialogResult.OK)
            {
                string selectedPath = dialog.SelectedPath;
                return selectedPath;
            }
            return "";
        }

        private void SourceFile_Click(object sender, RoutedEventArgs e)
        {
            SourceTextBox.Text = GetPathNew();
        }

        private void DestinationFile_Click(object sender, RoutedEventArgs e)
        {
            TargetTextBox.Text = GetPathNew();
        }


        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string source = SourceTextBox.Text;
            string target = TargetTextBox.Text;
            string name = NameTextBox.Text;

            bool typeFull = TypeFull.IsChecked.Value;
            bool typeDifferential = TypeDifferential.IsChecked.Value;

            bool nameAlreadyExist = false;
            foreach(Backup b in ViewModel.Backups)
            {
                if(b.Name == name) nameAlreadyExist = true;
            }
            if (!nameAlreadyExist)
            {
                if(source == "" || source == null) System.Windows.MessageBox.Show(Localizer.GetString("NoSource"));
                else if(target == "" || target == null) System.Windows.MessageBox.Show(Localizer.GetString("NoTarget"));
                else if (typeFull)
                {
                    ViewModel.CreateBackup(name, source, target, 1);
                    Close();
                }
                else if (typeDifferential)
                {
                    ViewModel.CreateBackup(name, source, target, 2);
                    Close();
                }
                else
                {
                    System.Windows.MessageBox.Show(Localizer.GetString("SelectBackup"));
                }
            } 
            else
            {
                System.Windows.MessageBox.Show(Localizer.GetString("NameAlreadyUsed"));
            }
        }

        private void GoBackButton_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
