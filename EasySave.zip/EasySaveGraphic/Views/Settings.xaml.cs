﻿using EasySave.Utils;
using EasySave.ViewModels;
using System.Text.RegularExpressions;
using System.Windows.Controls;
using System.Windows.Forms;


namespace EasySaveGraphic.Views
{
    /// <summary>
    /// Interaction logic for Settings.xaml
    /// </summary>
    public partial class Settings : Page
    {

        private MenuViewModel _viewModel;
        private MainWindow MenuParent;
        private Regex _regex = new Regex(@"^(-?)([1-9][0-9]*)?$");
        private string MaxFileSizePreviousText;

        public Settings(MenuViewModel viewModel, MainWindow mainWindow)
        {
            _viewModel = viewModel;
            InitializeComponent();
            CreateLanguagesCheckBoxes();
            CreateLogTypeCheckBoxes();
            LanguageUpdate();
            MenuParent = mainWindow;
            MaxFileSizeTextBox.Text = MenuViewModel.sConfig.FileSize.ToString();
            MaxFileSizePreviousText = MaxFileSizeTextBox.Text = MenuViewModel.sConfig.FileSize.ToString();
            BusinessSoftwareTextBox.Text = MenuViewModel.sConfig.BusinessSoftware;
            PriorityTextBox.Text = MenuViewModel.sConfig.ExtensionsPriority;
            CryptosoftTextBox.Text = MenuViewModel.sConfig.ExtensionsEncrypt;
        }

        private void CreateLanguagesCheckBoxes()
        {
            Languages.Children.Clear();
            string[] availableLanguages = Localizer.GetLanguages();
            for (int i = 0; i < availableLanguages.Length; i++)
            {
                System.Windows.Controls.RadioButton rb = new System.Windows.Controls.RadioButton()
                {
                    Content = availableLanguages[i],
                    IsChecked = availableLanguages[i] == MenuViewModel.sConfig.Language
                };

                rb.Checked += (senderobj, args) =>
                {
                    _viewModel.ChangeLanguage((senderobj as System.Windows.Controls.RadioButton).Content.ToString());
                    LanguageUpdate();
                    MenuParent.LanguageUpdate();
                };
                Languages.Children.Add(rb);
            }
        }

        private void CreateLogTypeCheckBoxes()
        {
            LogType.Children.Clear();
            string[] availableLogType = new string[] {"XML","JSON"};
            for (int i = 0; i < availableLogType.Length; i++)
            {
                System.Windows.Controls.RadioButton rb = new System.Windows.Controls.RadioButton()
                {
                    Content = availableLogType[i],
                    IsChecked = availableLogType[i] == MenuViewModel.sConfig.LogType

                };

                rb.Checked += (senderobj, args) =>
                {
                    _viewModel.ChangeLogType((senderobj as System.Windows.Controls.RadioButton).Content.ToString());
                };

                LogType.Children.Add(rb);
            }
        }

        public void LanguageUpdate()
        {
            Setting.Text = Localizer.GetString("Settings");
            //Label1.Content = Localizer.GetString("LogFileDirectory");
            //Label2.Content = Localizer.GetString("StatusFileDirectory");
            Label3.Content = Localizer.GetString("MaxFileSize");
            Label4.Content = Localizer.GetString("LogFileExtension");
            Label5.Content = Localizer.GetString("Language");
            Label6.Content = Localizer.GetString("BusinessSoftware");

        }

        /*
        private void LogFileSource_Click(object sender, RoutedEventArgs e)
        {
            LogFileSourceTextBox.Text = readPath();
        }

        private void StatusFileSource_Click(object sender, RoutedEventArgs e)
        {
            StatusFileSourceTextBox.Text = readPath();
        }
        */
        private string readPath()
        {
            FolderBrowserDialog dialog = new FolderBrowserDialog();
            DialogResult result = dialog.ShowDialog();

            if (result == System.Windows.Forms.DialogResult.OK)
            {
                string selectedPath = dialog.SelectedPath;
                return selectedPath;
            }
            return "";
        }
        

        private void textChangedEventHandler(object sender, TextChangedEventArgs args)
        {
            if (sender.Equals(MaxFileSizeTextBox))
            {
                if (_regex.IsMatch(MaxFileSizeTextBox.Text) && MaxFileSizeTextBox.Text.Trim() != "")
                {
                    _viewModel.ChangeMaxFileSize(long.Parse(MaxFileSizeTextBox.Text));
                    MaxFileSizePreviousText = MaxFileSizeTextBox.Text;
                }
                else if (MaxFileSizeTextBox.Text.Trim() == "")
                {
                    _viewModel.ChangeMaxFileSize(1);
                    MaxFileSizePreviousText = "1";
                    MaxFileSizeTextBox.Text = "1";
                }
                else MaxFileSizeTextBox.Text = MaxFileSizePreviousText;
            }
            if (sender.Equals(BusinessSoftwareTextBox))
            {
                _viewModel.ChangeBusinessSoftware(BusinessSoftwareTextBox.Text);
            }
            if (sender.Equals(PriorityTextBox))
            {
                _viewModel.ChangePriority(PriorityTextBox.Text);
            }
            if (sender.Equals(CryptosoftTextBox))
            {
                _viewModel.ChangeCryptosoft(CryptosoftTextBox.Text);   
            }

        }
    }
}
