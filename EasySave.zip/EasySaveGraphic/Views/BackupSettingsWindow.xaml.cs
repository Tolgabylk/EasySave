﻿using EasySave.Models.Backups;
using EasySave.Utils;
using EasySave.ViewModels;
using System.Collections.Generic;
using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Forms;

namespace EasySaveGraphic.Views
{
    /// <summary>
    /// Interaction logic for BackupSettingsWindow.xaml
    /// </summary>
    public partial class BackupSettingsWindow : Window
    {
        public MenuViewModel ViewModel;
        private Backup backup;
        private bool isFull = false;
        private bool isDifferential = false;
        public Dictionary<string, string> translation = new Dictionary<string, string>();

        private string _name;
        private string _source;
        private string _target;
        private string _type;

        public Backup Backup
        {
            get { return backup; }
            set
            {
                backup = value;
                RaisePropertyChanged("Backup");
            }
        }

        public Dictionary<string, string> Translation
        {
            get { return translation; }
            set
            {
                translation = value;
                RaisePropertyChanged("Translation");
            }
        }

        public bool IsFull
        {
            get { return isFull; }
            set
            {
                isFull = value;
                RaisePropertyChanged("IsFull");
            }
        }

        public bool IsDifferential
        {
            get { return isDifferential; }
            set
            {
                isDifferential = value;
                RaisePropertyChanged("IsDifferential");
            }
        }


        public BackupSettingsWindow(Backup backup, MenuViewModel viewModel) : this()
        {
            ViewModel = viewModel;
            Backup = backup;
            if (backup.BackupType.Name == "BackupFull") IsFull = true;
            else IsDifferential = true;
            _name = Backup.Name;
            _source = Backup.SourcePath;
            _target = Backup.TargetPath;
            _type = Backup.BackupType.Name;
        }

        public BackupSettingsWindow()
        {
            InitializeComponent();
            DataContext = this;
            LanguageUpdate();
        }

        private void LanguageUpdate()
        {
            CreateNewOrUpdateExisting(Translation, "BackupSettings", Localizer.GetString("BackupSettings"));
            CreateNewOrUpdateExisting(Translation, "Name", Localizer.GetString("Name"));
            CreateNewOrUpdateExisting(Translation, "Source", Localizer.GetString("Source"));
            CreateNewOrUpdateExisting(Translation, "Destination", Localizer.GetString("Destination"));
            CreateNewOrUpdateExisting(Translation, "Type", Localizer.GetString("Type"));
            CreateNewOrUpdateExisting(Translation, "BackupFull", Localizer.GetString("BackupFull"));
            CreateNewOrUpdateExisting(Translation, "BackupDifferential", Localizer.GetString("BackupDifferential"));
            CreateNewOrUpdateExisting(Translation, "Validate", Localizer.GetString("Validate"));
            CreateNewOrUpdateExisting(Translation, "GoBack", Localizer.GetString("GoBack"));
        }

        private void CreateNewOrUpdateExisting<TKey, TValue>(IDictionary<TKey, TValue> map, TKey key, TValue value)
        {
            map[key] = value;
        }

        private string GetPathNew()
        {
            FolderBrowserDialog dialog = new FolderBrowserDialog();
            DialogResult result = dialog.ShowDialog();

            if (result == System.Windows.Forms.DialogResult.OK)
            {
                string selectedPath = dialog.SelectedPath;
                return selectedPath;
            }
            return "";
        }

        private void SourceFile_Click(object sender, RoutedEventArgs e)
        {
            Backup.SourcePath = GetPathNew();
        }

        private void DestinationFile_Click(object sender, RoutedEventArgs e)
        {
            Backup.TargetPath = GetPathNew();
        }

        public event PropertyChangedEventHandler PropertyChanged = delegate { };

        private void RaisePropertyChanged(string propertyName)
        {
            var handlers = PropertyChanged;

            handlers(this, new PropertyChangedEventArgs(propertyName));
        }

        private void GoBackButton_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void AcceptButton_Click(object sender, RoutedEventArgs e)
        {
            if(ViewModel.ChangeBackup(Backup.Name, _name, _source, _target, _type)) Close();
            else System.Windows.MessageBox.Show(Localizer.GetString("NameAlreadyUsed"));
        }


        private void textChangedEventHandler(object sender, TextChangedEventArgs args)
        {
            switch (((System.Windows.Controls.TextBox)sender).Name)
            {
                case "Name":
                    _name = ((System.Windows.Controls.TextBox)sender).Text.Trim();
                    break;
                case "Source":
                    _source = ((System.Windows.Controls.TextBox)sender).Text;
                    break;
                case "Target":
                    _target = ((System.Windows.Controls.TextBox)sender).Text;
                    break;
            }
        }

        private void RadioButton_Checked(object sender, RoutedEventArgs args)
        {
            switch (((System.Windows.Controls.RadioButton)sender).Name)
            {
                case "TypeFull":
                    _type = "Full";
                    break;
                case "TypeDifferential":
                    _type = "Differential";
                    break;
            }
        }

    }
}
