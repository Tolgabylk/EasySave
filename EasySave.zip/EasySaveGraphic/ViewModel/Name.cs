﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EasySaveGraphic.ViewModel
{
    public class Name
    {
        public string BackupName { get; set; }
    }
}
