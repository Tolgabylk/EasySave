﻿using EasySave.Models.Backups;
using EasySave.ViewModels;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;
using System.Xml.Linq;

namespace EasySaveGraphic.ViewModel
{
    public class BackupListManager
    {
        public ObservableCollection<Backup> Backups;

        public BackupListManager()
        {
            MenuViewModel viewModel = new MenuViewModel();
            Backups = viewModel.Backups;
        }
    }
}
