﻿using CommandLine;
using System;
using System.IO;

namespace CryptoSoft
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Parser.Default.ParseArguments<Options>(args)
                .WithParsed<Options>(options =>
                {
                    if (int.TryParse(options.Key, out int key))
                    {
                        if (options.Encrypt)
                        {
                            try
                            {
                                Console.WriteLine($"Encrypting {options.Source}");
                                string text = EncryptUtils.EncryptDecrypt(File.ReadAllText(options.Source), key);
                                string encryptedFile = Path.ChangeExtension(options.Source, Path.GetExtension(options.Source) + ".crypted");
                                File.Move(options.Source, encryptedFile);
                                File.WriteAllText(encryptedFile, text);
                            }
                            catch (Exception e)
                            {
                                Console.WriteLine(e.Message);
                                Console.ReadLine();
                                Environment.Exit(0);
                            }
                        }
                        else if (options.Decrypt)
                        {
                            try
                            {
                                Console.WriteLine($"Decrypting {options.Source}");
                                string text = EncryptUtils.EncryptDecrypt(File.ReadAllText(options.Source), key);
                                string decryptedFile = Path.ChangeExtension(options.Source, "");
                                File.Move(options.Source, decryptedFile);
                                File.WriteAllText(decryptedFile, text);
                                Environment.Exit(0);
                            }
                            catch (Exception)
                            {
                                Environment.Exit(0);
                            }
                        }
                        else
                        {
                            Console.WriteLine("Please specify either --encrypt or --decrypt.");
                        }
                    }
                    else
                    {
                        Console.WriteLine("Invalid key specified.");
                    }
                })
                .WithNotParsed(errors =>
                {
                    Console.WriteLine("Error parsing command line arguments.");
                });
        }
    }
}
