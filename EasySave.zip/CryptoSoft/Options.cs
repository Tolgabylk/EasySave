﻿using CommandLine;

namespace CryptoSoft
{
    internal class Options
    {
        [Option('e', "encrypt", Required = false, HelpText = "Encrypt the source file.")]
        public bool Encrypt { get; set; }

        [Option('d', "decrypt", Required = false, HelpText = "Decrypt the source file.")]
        public bool Decrypt { get; set; }

        [Option('s', "source", Required = true, HelpText = "Path to the source file.")]
        public string Source { get; set; }

        [Option('k', "key", Required = true, HelpText = "Encryption key.")]
        public string Key { get; set; }
    }
}
