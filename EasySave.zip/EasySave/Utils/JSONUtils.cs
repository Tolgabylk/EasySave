﻿using EasySave.Models;
using EasySave.Models.Backups;
using EasySave.Models.Observers;
using EasySave.ViewModels;
using Newtonsoft.Json;
using System;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Threading;

namespace EasySave.Utils
{
    public static class JSONUtils
    {
        private static readonly string _DirectoryPath = @"EasySave";
        private static readonly string s_stateFilePath = @"EasySave/state.json";
        private static readonly string s_configFilePath = @"EasySave/config.json";
        private static readonly string _documentDirectoryPath = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + "/";


        private static ReaderWriterLock _rwl = new ReaderWriterLock();

        /// <summary>
        /// Read the backups in the state.json file
        /// </summary>
        /// <returns>List<BackupStrategy</returns>
        public static ObservableCollection<Backup> ReadState(MenuViewModel viewModel)
        {
            try
            {
                string jsonString = File.ReadAllText(_documentDirectoryPath+s_stateFilePath);
                var dynamicList = JsonConvert.DeserializeObject<dynamic>(jsonString);
                ObservableCollection<Backup> backups = new ObservableCollection<Backup>();
                for(int i = 0; i < dynamicList.Count; i++)
                {
                    dynamic dynamic = dynamicList[i];
                    Backup backup = null;
                    if(dynamic.BackupType == "BackupFull")
                    {
                        backup = viewModel.BackupFullFactory.CreateBackupFromState(
                                (string)dynamic.Name,
                                (string)dynamic.SourcePath,
                                (string)dynamic.TargetPath,
                                (long)dynamic.TotalFilesToCopy,
                                (long)dynamic.TotalFilesSize,
                                (long)dynamic.NbFilesLeftToDo
                                );
                    }
                    else if (dynamic.BackupType == "BackupDifferential")
                    {
                        backup = viewModel.BackupDifferentialFactory.CreateBackupFromState(
                                (string)dynamic.Name,
                                (string)dynamic.SourcePath,
                                (string)dynamic.TargetPath,
                                (long)dynamic.TotalFilesToCopy,
                                (long)dynamic.TotalFilesSize,
                                (long)dynamic.NbFilesLeftToDo
                                );
                    }
                    backup.Attach(new StateObserver(viewModel));
                    backup.Attach(new LogObserver());
                    backups.Add(backup);
                }
                return backups;
            }
            catch
            {
                return new ObservableCollection<Backup>();
            }
        }

        /// <summary>
        /// Override the state.json by changing the backup that changed or deleting it
        /// </summary>
        /// <param name="backup">backup that changed or got deleted</param>
        public static void WriteState(MenuViewModel viewModel)
        {
            _rwl.AcquireWriterLock(Timeout.Infinite);
            DirectoryUtils.IfNotExistCreateDirectory(_documentDirectoryPath + _DirectoryPath);
            using (var sw = new StreamWriter(_documentDirectoryPath + s_stateFilePath))
            {
                sw.Write(JsonConvert.SerializeObject(
                    viewModel.Backups.Select(backup => backup).ToList(), Formatting.Indented));
            }
            _rwl.ReleaseWriterLock();
        }

        public static void WriteConfig(Config config)
        {
            DirectoryUtils.IfNotExistCreateDirectory(_documentDirectoryPath + _DirectoryPath);
            File.WriteAllText(_documentDirectoryPath+s_configFilePath, JsonConvert.SerializeObject(config));
        }

        public static Config ReadConfig()
        {
            if(File.Exists(_documentDirectoryPath+s_configFilePath))
            {
                string jsonString = File.ReadAllText(_documentDirectoryPath+s_configFilePath);
                Config config = JsonConvert.DeserializeObject<Config>(jsonString);
                Localizer.ChangeLanguage(config.Language);
                return config;
            }
            else
            {
                return new Config(Localizer.GetCurrentLanguage(),"JSON", "", "", "", 1000);
            }
        }
    }

    public class ToStringJsonConverter : JsonConverter
    {
        public override bool CanConvert(Type objectType)
        {
            return true;
        }

        public override void WriteJson(JsonWriter writer, object value, JsonSerializer serializer)
        {
            writer.WriteValue(value.ToString());
        }

        public override bool CanRead
        {
            get { return false; }
        }

        public override object ReadJson(JsonReader reader, Type objectType, object existingValue, JsonSerializer serializer)
        {
            throw new NotImplementedException();
        }
    }
}