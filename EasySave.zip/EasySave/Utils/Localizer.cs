﻿using System;
using System.Resources;
using System.Reflection;
using System.Globalization;
using System.Linq;

namespace EasySave.Utils
{
    public static class Localizer
    {

        private static ResourceManager _rm;
        private static string[] _languages = new string[] { "en-US", "fr-FR" };

        static Localizer()
        {
            _rm = new ResourceManager("EasySave.Locales.Strings", Assembly.GetExecutingAssembly());
            if (!_languages.Contains(CultureInfo.InstalledUICulture.ToString())) ChangeLanguage("en-US");
        }

        /// <summary>
        /// Get a string from the locales. Usage : Localizer.GetString(Key)
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        public static string GetString(string key)
        {
            return _rm.GetString(key).Replace(@"\n", "" + System.Environment.NewLine);
        }

        /// <summary>
        /// Change the language of the locale. Usage :  Localizer.ChangeLanguage(Language);
        /// </summary>
        /// <param name="language">locale selected</param>
        public static void ChangeLanguage(string language)
        {
            var cultureInfo = new CultureInfo(language);
            CultureInfo.CurrentCulture = cultureInfo;
            CultureInfo.CurrentUICulture = cultureInfo;
        }

        public static string GetCurrentLanguage()
        {
            switch (CultureInfo.CurrentCulture.DisplayName)
            {
                case "Français (France)":
                    return "fr-FR";
                default:
                    return "en-US";
            }
        }

        /// <summary>
        /// Get a string formatted from the locales. Usage : Localizer.Format(Key1, Localizer.getString(Key2), "String3", ...);
        /// </summary>
        /// <param name="key">Key to get the string</param>
        /// <param name="args">Values to insert in the string</param>
        /// <returns>String formatted from the key and the args</returns>
        public static string Format(string key, params object?[] args)
        {
            return String.Format(_rm.GetString(key), args).Replace(@"\n", ""+System.Environment.NewLine);
        }

        /// <summary>
        /// Get the languages available
        /// </summary>
        /// <returns>Array of the languages available</returns>
        public static string[] GetLanguages()
        {
            return _languages;
        }
    }
}
