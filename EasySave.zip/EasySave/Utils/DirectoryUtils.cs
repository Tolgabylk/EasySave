﻿using System.IO;
using System.Linq;

namespace EasySave.Utils
{
    public static class DirectoryUtils
    {
        /// <summary>
        /// Get the number of files and the size of the files contained in the file or directory
        /// </summary>
        /// <param name="searchPath">Path to get the size informations of the file or directory</param>
        /// <returns></returns>
        public static (long nbFiles, long sizeFiles) GetFileAndDirectorySizeInfo(string searchPath)
        {
            long nbFiles = 0, sizeFiles = 0;
            if(File.Exists(searchPath))
            {
                nbFiles = 1;
                sizeFiles = new FileInfo(searchPath).Length;
            }
            else if (Directory.Exists(searchPath))
            {
                FileInfo[] files = new DirectoryInfo(searchPath).GetFiles("*.*", SearchOption.AllDirectories);
                nbFiles = files.Length;
                sizeFiles = files.ToList().Sum(f => f.Length);
            }
            return (nbFiles, sizeFiles);
        }

        /// <summary>
        /// Clear the file or directory
        /// </summary>
        /// <param name="clearPath">Path to clear the file or directory</param>
        public static void ClearFileAndDirectory(string clearPath)
        {
            if (Directory.Exists(clearPath))
            {
                Directory.Delete(clearPath, true);
                Directory.CreateDirectory(clearPath);
            }
            else if (File.Exists(clearPath))
            {
                File.Delete(clearPath);
            }
        }

        public static void IfNotExistCreateDirectory(string path)
        {
            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
            }
        }
    }
}
