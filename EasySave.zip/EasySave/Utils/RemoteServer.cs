﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Net.Sockets;
using System.Net;
using System.Threading;
using EasySave.Models.Backups;
using EasySave.ViewModels;
using Newtonsoft.Json;
using System.Collections.ObjectModel;
using Newtonsoft.Json.Linq;
using System.Diagnostics.SymbolStore;

namespace EasySaveGraphic.Utils
{

    internal class RemoteServer
    {
        private readonly Socket ServerSocket;
        public Socket ClientSocket;
        private MenuViewModel _viewModel;
        private bool _askingConnection = true;

        public RemoteServer(string ip, int port, MenuViewModel viewModel)
        {
            _viewModel = viewModel;
            IPEndPoint ServerEndPoint = new IPEndPoint(IPAddress.Parse(ip), port);
            ServerSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            ServerSocket.Bind(ServerEndPoint);
            ServerSocket.Listen(0);
            ClientAccept();
            DataReceiver();
            DataSender(_viewModel.Backups);
        }

        private void ClientAccept()
        {
            Thread t = new Thread(() =>
            {
                if (ClientSocket == null || !ClientSocket.Connected)
                {
                    ServerSocket.AcceptAsync().ContinueWith(t =>
                    {
                        ClientSocket = t.Result;
                        _askingConnection = false;
                    });
                }
            })
            {
                IsBackground = true
            };
            t.Start();
        }

        public Thread DataSender(ObservableCollection<Backup> backups)
        {
            Thread t = new Thread(() =>
            {
                while (true)
                {
                    try
                    {
                        if (ClientSocket != null && ClientSocket.Connected)
                        {
                            string json = JsonConvert.SerializeObject(backups);
                            byte[] buffer = Encoding.UTF8.GetBytes(json);
                            ClientSocket.Send(buffer);
                        } 
                        else if(ClientSocket != null && !ClientSocket.Connected && !_askingConnection || ClientSocket==null && !_askingConnection)
                        {
                            ClientAccept();
                            _askingConnection = true;
                        }
                    }
                    catch (SocketException)
                    {
                    }
                    Thread.Sleep(1000);
                }
            })
            {
                IsBackground = true
            };
            t.Start();

            return t;
        }

        private Thread DataReceiver()
        {
            Thread t = new Thread(() =>
            {
                while (true)
                {
                    if (ClientSocket != null && ClientSocket.Connected)
                    {
                        try
                        {
                            byte[] buffer = new byte[4096];
                            int received = ClientSocket.Receive(buffer);
                            byte[] data = new byte[received];
                            Array.Copy(buffer, data, received);
                            string json = Encoding.UTF8.GetString(data);
                            dynamic result = JObject.Parse(json);

                            switch ((int)result.Type)
                            {
                                case 1:
                                    _viewModel.SaveBackup((int)result.Id).Start();
                                    break;
                                case 2:
                                    _viewModel.PauseBackup((int)result.Id);
                                    break;
                                case 3:
                                    _viewModel.ResumeBackup((int)result.Id);
                                    break;
                                case 4:
                                    _viewModel.StopBackup((int)result.Id);
                                    break;
                                default:
                                    break;
                            }
                        }
                        catch (SocketException)
                        {
                        }
                    }
                    Thread.Sleep(1000);
                }
            })
            {
                IsBackground = true
            };
            t.Start();

            return t;
        }
    }
}