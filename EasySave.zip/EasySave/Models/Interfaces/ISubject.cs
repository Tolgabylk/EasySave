﻿
namespace EasySave.Models.Interfaces
{
    public interface ISubject
    {
        /// <summary>
        /// Attach an observer to the subject
        /// </summary>
        /// <param name="observer">Observer to attach</param>
        void Attach(IObserver observer);

        /// <summary>
        /// Detach an observer to the subject
        /// </summary>
        /// <param name="observer">Observer to detach</param>
        void Detach(IObserver observer);

        /// <summary>
        /// Notify all of the observers attached to the subject
        /// </summary>
        void Notify();
    }
}
