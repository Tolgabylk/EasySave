﻿
namespace EasySave.Models.Interfaces
{
    public interface IObserver
    {
        /// <summary>
        /// Observer design pattern event from the subject
        /// </summary>
        /// <param name="subject">Subject that emitted the event</param>
        void Update(ISubject subject);
    }
}
