﻿using EasySave.Models.Interfaces;
using EasySave.Utils;
using EasySave.ViewModels;

namespace EasySave.Models.Observers
{
    public class StateObserver : IObserver
    {
        private MenuViewModel _viewModel;

        public StateObserver(MenuViewModel viewModel)
        {
            _viewModel = viewModel;
        }
        
        /// <summary>
        /// Observer design pattern event from the subject
        /// </summary>
        /// <param name="subject">Subject that emitted the event</param>
        public void Update(ISubject subject)
        {
            JSONUtils.WriteState(_viewModel);
        }
    }
}
