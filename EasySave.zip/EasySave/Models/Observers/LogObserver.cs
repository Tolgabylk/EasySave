﻿using EasySave.Models.Backups;
using EasySave.Models.Interfaces;
using EasySave.Models.Logs;

namespace EasySave.Models.Observers
{
    public class LogObserver : IObserver
    {

        public static LogStrategy sLogStrategy;

        /// <summary>
        /// Observer design pattern event from the subject
        /// </summary>
        /// <param name="subject">Subject that emitted the event</param>
        public void Update(ISubject subject)
        {
            sLogStrategy.WriteLog((Backup)subject);
        }
    }
}
