﻿using EasySave.Models.Interfaces;
using EasySave.Utils;

namespace EasySave.Models.Observers
{
    public class ConfigObserver : IObserver
    {
        public void Update(ISubject subject)
        {
            JSONUtils.WriteConfig(subject as Config);
        }
    }
}
