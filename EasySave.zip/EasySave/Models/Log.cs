﻿namespace EasySave.Models
{
    public class Log
    {
        public string Name;
        public string FileSource;
        public string FileTarget;
        public string DestPath;
        public long FileSize;
        public double FileTransferTime;
        public string Time;
        public double FileEncryptTime;

        public Log() { }

        public Log(string name, string fileSource, string fileTarget, string destPath, long fileSize, double fileTransferTime, string time, double fileEncryptTime)
        {
            Name = name;
            FileSource = fileSource;
            FileTarget = fileTarget;
            DestPath = destPath;
            FileSize = fileSize;
            FileTransferTime = fileTransferTime;
            Time = time;
            FileEncryptTime = fileEncryptTime;
        }
    }
}
