﻿using EasySave.Models.Backups;
using EasySave.Utils;

namespace EasySave.Models.Factory
{
    public class BackupDifferentialFactory : BackupFactory
    {
        public BackupDifferentialFactory() { }


        /// <summary>
        /// Factory method to create a backup differential from scratch
        /// </summary>
        /// <param name="name">Name of the backup</param>
        /// <param name="sourcePath">Source path of the backup</param>
        /// <param name="targetPath">Target path of the backup</param>
        /// <returns>Backup differential created</returns>
        public override Backup CreateBackup(
            string name,
            string sourcePath,
            string targetPath
            )
        {
            (long totalFilesToCopy, long totalFilesSize) = DirectoryUtils.GetFileAndDirectorySizeInfo(sourcePath);

            BackupStrategy backupStrategy = new BackupDifferential();
            Backup backup = new Backup(name, sourcePath, targetPath, "END", totalFilesToCopy, totalFilesSize, totalFilesToCopy, 0, backupStrategy);
            backupStrategy.Backup = backup;
            return backup;
        }

        /// <summary>
        /// Factory method to create a backup differential from the state
        /// </summary>
        /// <param name="name">Name of the backup</param>
        /// <param name="sourcePath">Source path of the backup</param>
        /// <param name="targetPath">Target path of the backup</param>
        /// <param name="state">State of the backup [ACTIVE | END]</param>
        /// <param name="totalFilesToCopy">Number of files to copy</param>
        /// <param name="totalFilesSize">Size of all the files in the source directory</param>
        /// <param name="nbFilesLeftToDo">Number of files to copy left</param>
        /// <param name="progression">progression x/100</param>
        /// <returns>Backup differential created</returns>
        public override Backup CreateBackupFromState(
            string name,
            string sourcePath,
            string targetPath,
            long totalFilesToCopy,
            long totalFilesSize,
            long nbFilesLeftToDo
            )
        {
            BackupStrategy backupStrategy = new BackupDifferential();
            Backup backup = new Backup(name, sourcePath, targetPath, "END", totalFilesToCopy, totalFilesSize, nbFilesLeftToDo, 100, backupStrategy);
            backupStrategy.Backup = backup;
            return backup;
        }
    }
}
