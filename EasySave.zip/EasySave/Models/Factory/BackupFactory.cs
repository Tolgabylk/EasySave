﻿using EasySave.Models.Backups;

namespace EasySave.Models.Factory
{
    public abstract class BackupFactory
    {

        public BackupFactory()
        {

        }

        /// <summary>
        /// Abstract factory method to create a backup from scratch
        /// </summary>
        /// <param name="name">Name of the backup</param>
        /// <param name="sourcePath">Source path of the backup</param>
        /// <param name="targetPath">Target path of the backup</param>
        /// <returns>Backup created</returns>
        public abstract Backup CreateBackup(
            string name,
            string sourcePath,
            string targetPath
            );

        /// <summary>
        /// Abstract factory method to create a backup from the state
        /// </summary>
        /// <param name="name">Name of the backup</param>
        /// <param name="sourcePath">Source path of the backup</param>
        /// <param name="targetPath">Target path of the backup</param>
        /// <param name="state">State of the backup [ACTIVE | END]</param>
        /// <param name="totalFilesToCopy">Number of files to copy</param>
        /// <param name="totalFilesSize">Size of all the files in the source directory</param>
        /// <param name="nbFilesLeftToDo">Number of files to copy left</param>
        /// <param name="progression">progression x/100</param>
        /// <returns>Backup created</returns>
        public abstract Backup CreateBackupFromState(
            string name,
            string sourcePath,
            string targetPath,
            long totalFilesToCopy,
            long totalFilesSize,
            long nbFilesLeftToDo
            );
    }
}
