﻿using EasySave.Models.Interfaces;
using Newtonsoft.Json;
using System.Collections.Generic;

namespace EasySave.Models
{
    public class Config : ISubject
    {
        private string _language { get; set; }
        private string _logType { get; set; }
        private long _fileSize { get; set; }
        private string _extensionsPriority { get; set; }
        private string _extensionsEncrypt { get; set; }
        private string _businessSoftware { get; set; }
        private string _encryptKey { get; set; }

        public string Language
        {
            get { return _language; }
            set 
            { 
                _language = value;
                Notify();
            }
        }
        public string LogType
        {
            get { return _logType; }
            set
            {
                _logType = value;
                Notify();
            }
        }
        public long FileSize
        {
            get { return _fileSize; }
            set
            {
                _fileSize = value;
                Notify();
            }
        }
        public string ExtensionsPriority
        {
            get { return _extensionsPriority; }
            set 
            {
                _extensionsPriority = value;
                Notify(); 
            }
        }
        public string ExtensionsEncrypt
        {
            get { return _extensionsEncrypt; }
            set
            {
                _extensionsEncrypt = value;
                Notify();
            }
        }
        public string BusinessSoftware
        {
            get { return _businessSoftware; }
            set
            {
                _businessSoftware = value;
                Notify();
            }
        }

        public string EncryptKey
        {
            get { return _encryptKey; }
            set
            {
                _encryptKey = value;
                Notify();
            }
        }

        [JsonIgnore]
        private readonly List<IObserver> _observers;

        public Config(string language, string logType, string extensionsPriority, string extensionsCrypt, string businessSoftware, long fileSize)
        {
            _language = language;
            _logType = logType;
            _extensionsPriority = extensionsPriority;
            _extensionsEncrypt = extensionsCrypt;
            _fileSize = fileSize;
            _businessSoftware = businessSoftware;
            _observers = new List<IObserver>();
        }

        public void Attach(IObserver observer)
        {
            _observers.Add(observer);
        }

        public void Detach(IObserver observer)
        {
            _observers.Remove(observer);
        }

        public void Notify()
        {
            _observers.ForEach(observer => observer.Update(this));
        }
    }
}
