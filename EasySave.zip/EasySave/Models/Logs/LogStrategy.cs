﻿using EasySave.Models.Backups;

namespace EasySave.Models.Logs
{
    public abstract class LogStrategy
    {
        public abstract void WriteLog(Backup backup);

    }
}
