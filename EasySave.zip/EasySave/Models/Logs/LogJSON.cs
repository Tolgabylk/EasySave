﻿using EasySave.Models.Backups;
using EasySave.Utils;
using Newtonsoft.Json;
using System;
using System.IO;
using System.Threading;

namespace EasySave.Models.Logs
{
    public class LogJSON : LogStrategy
    {
        private readonly string _DirectoryPath = @"EasySave";
        private readonly string _logDirectoryPath = @"EasySave/Logs";
        private readonly string _logJSONDirectoryPath = @"EasySave/Logs/JSON";
        private readonly string _logFilePath = @"EasySave/Logs/JSON/{0}_log.json";
        private readonly string _documentDirectoryPath = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + "/";

        //private static volatile Mutex _mutex = new Mutex();

        private static ReaderWriterLock _rwl = new ReaderWriterLock();


        public LogJSON() { }

        /// <summary>
        /// Write in the log.json by adding the backup log
        /// </summary>
        /// <param name="backup">backup to log</param>
        public override void WriteLog(Backup backup)
        {
            if (!backup.Deleted && backup.LastFileUsed != null)
            {
                Log log = new Log(
                    backup.Name,
                    backup.LastFileUsed.FullName,
                    backup.LastFileUsed.FullName.Replace(backup.SourcePath, backup.TargetPath),
                    backup.LastFileUsed.Directory.FullName,
                    backup.LastFileUsed.Length,
                    backup.LastFileTransferTime,
                    backup.LastFileTime,
                    backup.LastFileEncryptTime
                    );
                string jsonLog = JsonConvert.SerializeObject(log, Formatting.Indented) + ",\n";
                string logFilePathToDate = String.Format(_logFilePath, DateTime.UtcNow.ToString("yyyy-MM-dd"));

                _rwl.AcquireWriterLock(Timeout.Infinite);
                DirectoryUtils.IfNotExistCreateDirectory(_documentDirectoryPath + _DirectoryPath);
                DirectoryUtils.IfNotExistCreateDirectory(_documentDirectoryPath + _logDirectoryPath);
                DirectoryUtils.IfNotExistCreateDirectory(_documentDirectoryPath + _logJSONDirectoryPath);
                using (var sw = new StreamWriter(_documentDirectoryPath + logFilePathToDate, true))
                {
                    sw.Write(jsonLog);
                }
                _rwl.ReleaseWriterLock();
            }

        }

    }
}
