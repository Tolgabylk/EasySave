﻿using EasySave.Models.Backups;
using EasySave.Utils;
using System;
using System.IO;
using System.Threading;
using System.Xml;
using System.Xml.Serialization;
using Formatting = System.Xml.Formatting;

namespace EasySave.Models.Logs
{
    public class LogXML : LogStrategy
    {
        private readonly string _DirectoryPath = @"EasySave";
        private readonly string _logDirectoryPath = @"EasySave/Logs";
        private readonly string _logXMLDirectoryPath = @"EasySave/Logs/XML";
        private readonly string _logFilePath = @"EasySave/Logs/XML/{0}_log.xml";
        private readonly string _documentDirectoryPath = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + "/";

        private static Mutex _mutex = new Mutex();

        public LogXML() { }

        /// <summary>
        /// Write in the log.xml by adding the backup log
        /// </summary>
        /// <param name="backup">backup to log</param>
        public override void WriteLog(Backup backup)
        {
            if (!backup.Deleted && backup.LastFileUsed != null)
            {
                Log log = new Log(backup.Name, 
                    backup.LastFileUsed.FullName, 
                    backup.LastFileUsed.FullName.Replace(backup.SourcePath, backup.TargetPath), 
                    backup.LastFileUsed.Directory.FullName, 
                    backup.LastFileUsed.Length,
                    backup.LastFileTransferTime,
                    backup.LastFileTime,
                    backup.LastFileEncryptTime
                    );

                XmlSerializer xsSubmit = new XmlSerializer(typeof(Log));
                using var sww = new StringWriter();
                using XmlTextWriter writer = new XmlTextWriter(sww) { Formatting = Formatting.Indented };
                xsSubmit.Serialize(writer, log);
                var xml = sww.ToString() + Environment.NewLine;
                string logFilePathToDate = String.Format(_logFilePath, DateTime.UtcNow.ToString("yyyy-MM-dd"));

                _mutex.WaitOne();
                DirectoryUtils.IfNotExistCreateDirectory(_documentDirectoryPath + _DirectoryPath);
                DirectoryUtils.IfNotExistCreateDirectory(_documentDirectoryPath + _logDirectoryPath);
                DirectoryUtils.IfNotExistCreateDirectory(_documentDirectoryPath + _logXMLDirectoryPath);
                File.AppendAllText(_documentDirectoryPath+ logFilePathToDate, xml);
                _mutex.ReleaseMutex();
            }

        }

    }

}
