﻿using EasySave.Utils;
using EasySave.ViewModels;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Threading;

namespace EasySave.Models.Backups
{
    /// <summary>
    /// Abstract class to create a backup, not typed
    /// </summary>
    [JsonConverter(typeof(ToStringJsonConverter))]
    public abstract class BackupStrategy
    {
        public string Name { get; set; }
        public Backup Backup { get; set; }
        private readonly Stopwatch _stopwatch;
        private readonly Stopwatch _stopwatchCrypt;
        protected List<FileInfo> prioFileInfo = new List<FileInfo>();

        private static volatile Mutex _mutexBigFiles = new Mutex();
        protected static volatile ManualResetEvent _mrePrioritizeFiles = new ManualResetEvent(true);
        public ManualResetEvent MREPlayPause = new ManualResetEvent(true);

        protected static List<BackupStrategy> savingPrioBackups = new List<BackupStrategy>();

        private static int cryptKey = 1234;



        /// <summary>
        /// Abstract constructor to create a Backup not typed
        /// </summary>
        /// <param name="name">Name of the backup</param>
        /// <param name="sourcePath">Source path of the backup</param>
        /// <param name="targetPath">Target path of the backup</param>
        /// <param name="state">State of the backup [ACTIVE | END]</param>
        /// <param name="totalFilesToCopy">Number of files to copy</param>
        /// <param name="totalFilesSize">Size of all the files in the source directory</param>
        /// <param name="nbFilesLeftToDo">Number of files to copy left</param>
        /// <param name="progression">progression x/100</param>
        public BackupStrategy(string name)
        {
            Name = name;
            _stopwatch = new Stopwatch();
            _stopwatchCrypt = new Stopwatch();
        }

        public void Save()
        {
            // Initialize the save state
            (long totalFilesToCopy, long totalFilesSize) = DirectoryUtils.GetFileAndDirectorySizeInfo(Backup.SourcePath);
            Backup.State = "ACTIVE";
            Backup.TotalFilesToCopy = totalFilesToCopy;
            Backup.TotalFilesSize = totalFilesSize;
            Backup.NbFilesLeftToDo = totalFilesToCopy;
            Backup.Progression = 0;
            MREPlayPause.Set();

            SaveType();

            Backup.LastFileUsed = null;
            Backup.Progression = 100;
            Backup.State = "END";
            Backup.Notify();
        }

        public void Pause()
        {
            MREPlayPause.Reset();
            if (savingPrioBackups.Contains(this))
            {
                savingPrioBackups.Remove(this);
                if(savingPrioBackups.Count> 0)
                {
                    _mrePrioritizeFiles.Set();
                }
            }
        }

        public void Resume()
        {
            MREPlayPause.Set();
            if(prioFileInfo.Count> 0)
            {
                _mrePrioritizeFiles.Set();
                savingPrioBackups.Add(this);
            }
        }

        /// <summary>
        /// Save the current backup and log every file copied and state
        /// </summary>
        /// <returns>Name of the backup to save</returns>
        protected abstract void SaveType();

        private void FileCopyOrDelete(FileInfo file, FileAction action)
        {
            Backup.LastFileTime = DateTime.UtcNow.ToString();
            string targetFilePath = file.FullName.Replace(Backup.SourcePath, Backup.TargetPath);
            _stopwatch.Restart();
            switch (action)
            {
                case FileAction.COPY:
                    File.WriteAllText(targetFilePath, File.ReadAllText(file.FullName));
                    _stopwatchCrypt.Restart();
                    if (IsValidExtension(file.Extension, MenuViewModel.sConfig.ExtensionsEncrypt.Split(";")))
                    {

                        Process p =  Process.Start("CryptoSoft.exe", $"--encrypt --source \"{targetFilePath}\" --key {cryptKey}");
                        p.WaitForExit();
                    }
                    _stopwatchCrypt.Stop();
                    break;
                case FileAction.DELETE:
                    file.Delete();
                    break;
            }
            _stopwatch.Stop();
            Backup.NbFilesLeftToDo--;
            Backup.LastFileUsed = file;
            Backup.LastFileTransferTime = _stopwatch.Elapsed.TotalSeconds;
            Backup.LastFileEncryptTime = _stopwatchCrypt.Elapsed.TotalSeconds;
            Backup.Progression = 100 - (int)(Backup.NbFilesLeftToDo * 100 / Backup.TotalFilesToCopy);
            Backup.Notify();
        }

        protected void FileCopy(FileInfo file)
        {
            MREPlayPause.WaitOne();
            if (file.Length > MenuViewModel.sConfig.FileSize*1000)
            {
                try
                {
                    _mutexBigFiles.WaitOne();
                    FileCopyOrDelete(file, FileAction.COPY);
                    _mutexBigFiles.ReleaseMutex();
                } 
                catch (AbandonedMutexException e)
                {
                    _mutexBigFiles.ReleaseMutex();
                }
            }
            else
            {
                FileCopyOrDelete(file, FileAction.COPY);
            }
        }

        protected void FileDelete(FileInfo file)
        {
            MREPlayPause.WaitOne();
            FileCopyOrDelete(file, FileAction.DELETE);
        }

        public override string ToString()
        {
            return Name;
        }
        
        protected bool IsValidExtension(string extension, string[] extensions)
        {
            bool res = true;
            int index = 0;
            while (res && index < extensions.Length)
            {
                res = extension == "." + extensions[index];
                index++;
            }
            return res;
        }
    }

    public enum FileAction
    {
        COPY, DELETE
    }
}
