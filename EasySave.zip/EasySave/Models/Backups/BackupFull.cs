﻿using EasySave.Utils;
using EasySave.ViewModels;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;

namespace EasySave.Models.Backups
{
    public class BackupFull : BackupStrategy
    {
        /// <summary>
        /// Constructor to create a Backup typed Full
        /// </summary>
        /// <param name="name">Name of the backup</param>
        /// <param name="sourcePath">Source path of the backup</param>
        /// <param name="targetPath">Target path of the backup</param>
        /// <param name="state">State of the backup [ACTIVE | END]</param>
        /// <param name="totalFilesToCopy">Number of files to copy</param>
        /// <param name="totalFilesSize">Size of all the files in the source directory</param>
        /// <param name="nbFilesLeftToDo">Number of files to copy left</param>
        /// <param name="progression">progression x/100</param>
        public BackupFull() : base("BackupFull")
        {
        }

        /// <summary>
        /// Save the current backup and log every file copied and state
        /// </summary>
        /// <returns>Name of the backup to save</returns>
        protected override void SaveType()
        {
            Console.WriteLine(Name);
            if (File.Exists(Backup.SourcePath))
            {
                FileCopy(new FileInfo(Backup.SourcePath));
            }
            else
            {
                DirectoryInfo sourceDir = new DirectoryInfo(Backup.SourcePath);
                DirectoryUtils.ClearFileAndDirectory(Backup.TargetPath);

                DirectoryInfo[] directories = sourceDir.GetDirectories("*.*", SearchOption.AllDirectories);
                directories.ToList().ForEach((dir) => Directory.CreateDirectory(dir.FullName.Replace(Backup.SourcePath, Backup.TargetPath)));

                List<FileInfo> files = sourceDir.GetFiles("*.*", SearchOption.AllDirectories).ToList();

                prioFileInfo = files.ToList().FindAll(file => IsValidExtension(file.Extension, MenuViewModel.sConfig.ExtensionsPriority.Split(";")));

                if(prioFileInfo != null && prioFileInfo.Count > 0)
                {
                    savingPrioBackups.Add(this);
                    _mrePrioritizeFiles.Reset();

                    prioFileInfo.ForEach(prioritizeFile => FileCopy(prioritizeFile));

                    savingPrioBackups.Remove(this);
                    if (savingPrioBackups.Count == 0) _mrePrioritizeFiles.Set();
                }
                files = files.Except(prioFileInfo).ToList();

                files.ForEach(file =>
                {
                    _mrePrioritizeFiles.WaitOne();
                    FileCopy(file);
                });
            }
        }
    }
}
