﻿using EasySave.Utils;
using EasySave.ViewModels;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;

namespace EasySave.Models.Backups
{
    internal class BackupDifferential : BackupStrategy
    {
        public BackupDifferential() : base("BackupDifferential")
        {
        }

        protected override void SaveType()
        {
            if (File.Exists(Backup.SourcePath))
            {
                FileInfo file = new FileInfo(Backup.SourcePath);
                FileInfo targetFile = new FileInfo(Backup.TargetPath);
                if(targetFile.LastAccessTime < file.LastAccessTime) 
                {
                    FileCopy(file);
                }
            }
            else
            {
                DirectoryInfo sourceDir = new DirectoryInfo(Backup.SourcePath);
                DirectoryInfo targetDir = new DirectoryInfo(Backup.TargetPath);

                List<DirectoryInfo> directoriesSource = sourceDir.GetDirectories("*.*", SearchOption.AllDirectories).ToList();
                List<DirectoryInfo> directoriesTarget = targetDir.GetDirectories("*.*", SearchOption.AllDirectories).ToList();

                directoriesSource.ToList().ForEach((directorySource) =>
                {
                    string directoryTargetPath = directorySource.FullName.Replace(sourceDir.FullName, targetDir.FullName);
                    if (!Directory.Exists(directoryTargetPath))
                    {
                        Directory.CreateDirectory(directoryTargetPath);
                    }
                });

                directoriesTarget.ToList().ForEach((directoryTarget) =>
                {
                    string directorySourcePath = directoryTarget.FullName.Replace(targetDir.FullName, sourceDir.FullName);
                    if (!Directory.Exists(directorySourcePath))
                    {
                        Directory.Delete(directoryTarget.FullName, true);
                    }
                });

                List<FileInfo> filesSource = sourceDir.GetFiles("*.*", SearchOption.AllDirectories).ToList();
                List<FileInfo> filesTarget = targetDir.GetFiles("*.*", SearchOption.AllDirectories).ToList();

                prioFileInfo = filesSource.ToList().FindAll(file => IsValidExtension(file.Extension, MenuViewModel.sConfig.ExtensionsPriority.Split(";")));

                if (prioFileInfo != null && prioFileInfo.Count > 0)
                {
                    savingPrioBackups.Add(this);
                    _mrePrioritizeFiles.Reset();

                    prioFileInfo.ForEach(prioritizeFile =>
                    {
                        string fileTargetPath = prioritizeFile.FullName.Replace(sourceDir.FullName, targetDir.FullName);
                        if (!File.Exists(fileTargetPath))
                        {
                            FileCopy(prioritizeFile);
                        }
                        else
                        {
                            FileInfo fileTarget = new FileInfo(fileTargetPath);
                            if (fileTarget.LastWriteTime < prioritizeFile.LastWriteTime)
                            {
                                FileCopy(prioritizeFile);
                            }
                            filesTarget.RemoveAll(file => file.FullName == fileTarget.FullName);
                        }
                    });

                    savingPrioBackups.Remove(this);
                    if (savingPrioBackups.Count == 0) _mrePrioritizeFiles.Set();
                }
                filesSource = filesSource.Except(prioFileInfo).ToList();

                filesSource.ForEach(fileSource =>
                {
                    string fileTargetPath = fileSource.FullName.Replace(sourceDir.FullName, targetDir.FullName);
                    if (!File.Exists(fileTargetPath))
                    {
                        FileCopy(fileSource);
                    }
                    else
                    {
                        FileInfo fileTarget = new FileInfo(fileTargetPath);
                        if (fileTarget.LastWriteTime < fileSource.LastWriteTime)
                        {
                            FileCopy(fileTarget);
                        }
                        filesTarget.RemoveAll(file => file.FullName == fileTarget.FullName);
                    }
                });
                filesTarget.ForEach(fileTarget => 
                {
                    FileDelete(fileTarget);
                });
            }
        }
    }
}
