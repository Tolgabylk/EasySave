﻿using EasySave.Models.Interfaces;
using EasySave.Utils;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Threading;

namespace EasySave.Models.Backups
{
    public class Backup : ISubject, INotifyPropertyChanged
    {
        private string name;
        public string Name
        {
            get { return name; }
            set
            {
                if (value != this.name)
                {
                    this.name = value;
                    NotifyPropertyChanged("Name");
                }
            }
        }

        private string sourcePath;
        public string SourcePath
        {
            get { return sourcePath; }
            set
            {
                if (value != this.sourcePath)
                {
                    this.sourcePath = value;
                    NotifyPropertyChanged("SourcePath");
                }
            }
        }

        private string targetPath;
        public string TargetPath
        {
            get { return targetPath; }
            set
            {
                if (value != this.targetPath)
                {
                    this.targetPath = value;
                    NotifyPropertyChanged("TargetPath");
                }
            }
        }

        private string state;
        public string State
        {
            get { return state; }
            set
            {
                if (value != this.state)
                {
                    this.state = value;
                    NotifyPropertyChanged("State");
                }
            }
        }

        private long totalFilesToCopy;
        public long TotalFilesToCopy
        {
            get { return totalFilesToCopy; }
            set
            {
                if (value != this.totalFilesToCopy)
                {
                    this.totalFilesToCopy = value;
                    NotifyPropertyChanged("TotalFilesToCopy");
                }
            }
        }

        private long totalFilesSize;
        public long TotalFilesSize
        {
            get { return totalFilesSize; }
            set
            {
                if (value != this.totalFilesSize)
                {
                    this.totalFilesSize = value;
                    NotifyPropertyChanged("TotalFilesSize");
                }
            }
        }

        private long nbFilesLeftToDo;
        public long NbFilesLeftToDo
        {
            get { return nbFilesLeftToDo; }
            set
            {
                if (value != this.nbFilesLeftToDo)
                {
                    this.nbFilesLeftToDo = value;
                    NotifyPropertyChanged("NbFilesLeftToDo");
                }
            }
        }

        private int progression;
        public int Progression
        {
            get { return progression; }
            set
            {
                if (value != this.progression)
                {
                    this.progression = value;
                    NotifyPropertyChanged("Progression");
                }
            }
        }

        private BackupStrategy backupType;
        public BackupStrategy BackupType
        {
            get { return backupType; }
            set
            {
                if (value != this.backupType)
                {
                    this.backupType = value;
                    NotifyPropertyChanged("BackupType");
                    switch (value.Name)
                    {
                        case "BackupFull":
                            BackupTypeLanguage = Localizer.GetString("BackupFullText");
                            break;
                        case "BackupDifferential":
                            BackupTypeLanguage = Localizer.GetString("BackupDifferentialText");
                            break;
                    }
                }
            }
        }

        [JsonIgnore]
        private string backupTypeLanguage;
        [JsonIgnore]
        public string BackupTypeLanguage
        {
            get { return backupTypeLanguage; }
            set
            {
                if (value != this.backupTypeLanguage)
                {
                    this.backupTypeLanguage = value;
                    NotifyPropertyChanged("BackupTypeLanguage");
                }
            }
        }


        [JsonIgnore]
        public bool Deleted = false;
        [JsonIgnore]
        private readonly List<IObserver> _observers;

        [JsonIgnore]
        public FileInfo LastFileUsed { get; set; }
        [JsonIgnore]
        public double LastFileTransferTime { get; set; }
        [JsonIgnore]
        public double LastFileEncryptTime { get; set; }
        [JsonIgnore]
        public FileAction LastFileAction { get; set; }
        [JsonIgnore]
        public string LastFileTime { get; set; }

        /// <summary>
        /// Abstract constructor to create a Backup not typed
        /// </summary>
        /// <param name="name">Name of the backup</param>
        /// <param name="sourcePath">Source path of the backup</param>
        /// <param name="targetPath">Target path of the backup</param>
        /// <param name="state">State of the backup [ACTIVE | END]</param>
        /// <param name="totalFilesToCopy">Number of files to copy</param>
        /// <param name="totalFilesSize">Size of all the files in the source directory</param>
        /// <param name="nbFilesLeftToDo">Number of files to copy left</param>
        /// <param name="progression">progression x/100</param>
        public Backup(
            string name,
            string sourcePath,
            string targetPath,
            string state,
            long totalFilesToCopy,
            long totalFilesSize,
            long nbFilesLeftToDo,
            int progression,
            BackupStrategy backupType
            )
        {
            Name = name;
            SourcePath = sourcePath;
            TargetPath = targetPath;
            State = state;
            TotalFilesToCopy = totalFilesToCopy;
            TotalFilesSize = totalFilesSize;
            NbFilesLeftToDo = nbFilesLeftToDo;
            Progression = progression;
            BackupType = backupType;
            _observers = new List<IObserver>();
        }

        /// <summary>
        /// Save the current backup and log every file copied and state
        /// </summary>
        /// <returns>Name of the backup to save</returns>
        public void Save()
        {
            try
            {
                BackupType.Save();
            }
            catch (ThreadInterruptedException ex)
            {
                //BackupType.ReleaseMutexBigFiles();
                LastFileUsed = null;
                State = "STOP";
                Notify();
                return;
            }
        }

        public void Pause()
        {
            BackupType.Pause();
            State = "PAUSE";
        }

        public void Resume()
        {
            BackupType.Resume();
            State = "ACTIVE";
        }

        public void Error()
        {
            State = "ERROR";
        }

        public void Reset()
        {
            State = "END";
            Progression = 100;
        }

        public void ChangeBackupType(BackupStrategy type)
        {
            BackupType = type;
            type.Backup = this;
            Notify();
        }

        /// <summary>
        /// Get the printable backup string
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            return Localizer.Format("BackupFromTo", Localizer.GetString(BackupType.Name), Name, SourcePath, TargetPath);
        }

        /// <summary>
        /// Delete the backup by removing it from the state
        /// </summary>
        public void Delete()
        {
            Deleted = true;
            Notify();
        }

        /// <summary>
        /// Attach an observer to the observer list _observers
        /// </summary>
        /// <param name="observer">Observer to attach</param>
        public void Attach(IObserver observer)
        {
            _observers.Add(observer);
        }

        /// <summary>
        /// Detach an observer to the observer list _observers
        /// </summary>
        /// <param name="observer">Observer to detach</param>
        public void Detach(IObserver observer)
        {
            _observers.Remove(observer);
        }

        /// <summary>
        /// Notify all of the observers in the list _observers
        /// </summary>
        public void Notify()
        {
            _observers.ForEach(observer =>
            {
                observer.Update(this);
            });
        }

        public event PropertyChangedEventHandler PropertyChanged;

        private void NotifyPropertyChanged(String info)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(info));
        }
    }
}
