Code Style Privacy 

variable : camelCase
attribut : PascalCase
private attribut : _camelCase
private static attribut : s_camelCase
static attribut : scamelCase
constant : SCREAMING_SNAKE_CASE
method : PascalCase
private method : _PascalCase
class : PascalCase

