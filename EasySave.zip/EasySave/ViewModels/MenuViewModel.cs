﻿using System.Collections.Generic;
using EasySave.Models;
using EasySave.Models.Backups;
using EasySave.Models.Factory;
using EasySave.Models.Logs;
using EasySave.Utils;
using EasySave.Models.Observers;
using System.Threading.Tasks;
using System.Threading;
using System.Collections.ObjectModel;
using EasySaveGraphic.Utils;
using System.Linq;
using System.Diagnostics;
using System.IO;

namespace EasySave.ViewModels
{
    public class MenuViewModel
    {
        public readonly ObservableCollection<Backup> Backups;
        public readonly Dictionary<string, Thread> Threads;

        public readonly BackupFactory BackupFullFactory;
        public readonly BackupFactory BackupDifferentialFactory;
        public static Config sConfig;
        private RemoteServer ProgressSocket;

        public MenuViewModel()
        {
            BackupFullFactory = new BackupFullFactory();
            BackupDifferentialFactory = new BackupDifferentialFactory();
            Threads = new Dictionary<string, Thread>();
            sConfig = JSONUtils.ReadConfig();
            switch (sConfig.LogType)
            {
                case "XML":
                    LogObserver.sLogStrategy = new LogXML();
                    break;
                case "JSON":
                    LogObserver.sLogStrategy = new LogJSON();
                    break;
            }
            sConfig.Attach(new ConfigObserver());
            Backups = JSONUtils.ReadState(this);
            ProgressSocket = new RemoteServer("127.0.0.1", 9050, this);
            _LaunchBusinessSoftwareThread();
        }

        /// <summary>
        /// Save the backup
        /// </summary>
        /// <param name="index">Index of the backup to save in BackupStrategies</param>
        /// <returns>Name of the backup saved</returns>
        public Thread SaveBackup(int index)
        {
            Backup b = Backups[index];
            Thread t = null;
            if (Directory.Exists(b.SourcePath) && Directory.Exists(b.TargetPath) && !Threads.ContainsKey(b.Name))
            {
                ThreadStart tS = new ThreadStart(b.Save);
                tS += () => Threads.Remove(b.Name);
                t = new Thread(tS);
                Threads.Add(b.Name, t);
            }
            return t;
        }

        public void SaveBackups(int[] indexes)
        {
            for(int i = 0; i < indexes.Length; i++)
            {
                Backup b = Backups[indexes[i]];
                if(!Threads.ContainsKey(b.Name))
                {
                    ThreadStart tS = new ThreadStart(b.Save);
                    tS += () => Threads.Remove(b.Name);
                    Thread t = new Thread(tS);
                    Threads.Add(b.Name, t);
                    t.Start();
                }
            }
        }

        public void PauseBackup(int index)
        {
            Backups[index].Pause();
        }

        public void ResumeBackup(int index)
        {
            Backups[index].Resume();
        }

        public void ErrorBackup(int index)
        {
            StopBackup(index);
            Backups[index].Error();
        }


        public void ResetBackup(int index)
        {
            Backups[index].Reset();
        }

        public void StopBackup(int index)
        {
            if(index < Backups.Count)
            {
                Backup b = Backups[index];
                if (b != null && Threads.ContainsKey(b.Name))
                {
                    Threads[b.Name].Interrupt();
                    Threads.Remove(b.Name);
                }
            }
        }

        /// <summary>
        /// Create a backup from scratch
        /// </summary>
        /// <param name="name">Name of the backup</param>
        /// <param name="sourcePath">Source folder or file of the backup</param>
        /// <param name="targetPath">Target folder or file of the backup</param>
        /// <param name="type">Type of the backup</param>
        public void CreateBackup(string name, string sourcePath, string targetPath, int type)
        {
            Backup backup = null;
            switch (type)
            {
                case 1:
                    backup = BackupFullFactory.CreateBackup(name, sourcePath, targetPath);
                    break;
                case 2:
                    backup = BackupDifferentialFactory.CreateBackup(name, sourcePath, targetPath);
                    break;
            }
            backup.Attach(new StateObserver(this));
            backup.Attach(new LogObserver());
            Backups.Add(backup);
            SaveBackup(Backups.Count - 1).Start();
        }

        /// <summary>
        /// Delete the backup
        /// </summary>
        /// <param name="index">Index of the backup to delete in BackupStrategies</param>
        /// <returns>Name of the backup</returns>
        public string DeleteBackup(int index)
        {
            if (index < Backups.Count)
            {
                Backup backup = Backups[index];
                backup.Delete();
                Backups.RemoveAt(index);
                return backup.Name;
            }
            else
            {
                return null;
            }
        }

        public (string, string) ChangeType(int index, int type)
        {
            Backup backup = Backups[index];
            BackupStrategy backupType = null;
            switch (type)
            {
                case 1:
                    backupType = new BackupFull();
                    break;
                case 2:
                    backupType = new BackupDifferential();
                    break;

            }
            backup.ChangeBackupType(backupType);
            return (backup.Name, backupType.Name);
        }

        public void ChangeLanguage(string language)
        {
            Localizer.ChangeLanguage(language);
            sConfig.Language = language;
        }

        public void ChangeLogType(string logType)
        {
            switch (logType)
            {
                case "XML":
                    LogObserver.sLogStrategy = new LogXML();
                    break;
                case "JSON":
                    LogObserver.sLogStrategy = new LogJSON();
                    break;
            }
            sConfig.LogType = logType;
        }

        public void ChangeMaxFileSize(long fileSize)
        {
            sConfig.FileSize = fileSize;
        }

        public void ChangeBusinessSoftware(string businessSoftware)
        {
            sConfig.BusinessSoftware = businessSoftware;
        }

        public void ChangePriority(string prio)
        {
            sConfig.ExtensionsPriority = prio;
        }
        public void ChangeCryptosoft(string crypt)
        {
            sConfig.ExtensionsEncrypt = crypt;
        }


        private void _LaunchBusinessSoftwareThread()
        {
            Thread t = new Thread(() =>
            {
                bool stopped = false;
                while (true)
                {
                    Process process = Process.GetProcesses().ToList().Find(p => p.ProcessName == sConfig.BusinessSoftware);
                    if (!stopped && process != null)
                    {
                        stopped = true;
                        for (int i = 0; i < Backups.Count; i++)
                        {
                            ErrorBackup(i);
                        }
                    }
                    else if (stopped && process == null)
                    {
                        stopped = false;
                        for (int i = 0; i < Backups.Count; i++)
                        {
                            ResetBackup(i);
                        }
                    }
                    Thread.Sleep(1000);
                }
            })
            {
                IsBackground = true
            };
            t.Start();
        }

        public bool ChangeBackup(string oldName, string newName, string source, string target, string type)
        {
            int nbNameAlreayExist = 0;
            foreach (Backup backup in Backups)
            {
                if(backup.Name == newName && backup.Name != oldName) nbNameAlreayExist++;
            }
            if (nbNameAlreayExist > 0) return false;

            BackupStrategy backupType = null;
            switch (type)
            {
                case "Full":
                    backupType = new BackupFull();
                    break;
                case "Differential":
                    backupType = new BackupDifferential();
                    break;

            }
            Backup e = Backups.First(e => e.Name == oldName);
            e.Name = newName;
            e.SourcePath= source;
            e.TargetPath= target;
            e.ChangeBackupType(backupType);
            return true;
        }
    }
}
