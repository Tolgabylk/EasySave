﻿using System.Collections.Generic;
using System.Text;
using System.Net.Sockets;
using System.Net;
using System.Threading;
using EasySaveClient.Models;
using EasySaveClient;
using Newtonsoft.Json;

namespace EasySaveGraphic.Utils
{

    internal class RemoteClient
    {
        private readonly Socket _serverSocket;
        private MainWindow _mainWindow;
        private IPEndPoint _ipEndPoint;


        public RemoteClient(string ip, int port, MainWindow mainWindow)
        {
            _mainWindow = mainWindow;
            _ipEndPoint = new IPEndPoint(IPAddress.Parse(ip), port);
            _serverSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            ConnectToServer();
        }

        private void ConnectToServer()
        {
            Thread t = new Thread(() =>
            {
                while(true)
                {
                    if (!_serverSocket.Connected)
                    {
                        try
                        {
                            _serverSocket.ConnectAsync(_ipEndPoint).ContinueWith(t =>
                            {
                                if (_serverSocket.Connected)
                                {
                                    _mainWindow.SocketName = $"Connected to server : {_ipEndPoint.Address}:{_ipEndPoint.Port}";
                                    ReceiveData();
                                }
                            });
                        }
                        catch (SocketException)
                        {
                            _mainWindow.SocketName = "Connection lost... retrying every 5 seconds";
                            _mainWindow.BackupList = null;
                            Thread.Sleep(5000);
                        }
                    }
                }
            })
            {
                IsBackground = true
            };
            t.Start();
        }

        private Thread ReceiveData()
        {
            Thread t = new Thread(() =>
            {
                while(true)
                {
                    if (_serverSocket != null && _serverSocket.Connected)
                    {
                        try
                        {
                            byte[] buffer = new byte[4096];
                            int bytesReceived = _serverSocket.Receive(buffer);
                            string data = Encoding.UTF8.GetString(buffer, 0, bytesReceived);
                            var dynamicList = JsonConvert.DeserializeObject<dynamic>(data);

                            List<BackupTemp> dummyList = new List<BackupTemp>();
                            if (dynamicList != null)
                            {
                                for (int i = 0; i < dynamicList.Count; i++)
                                {
                                    dummyList.Add(new BackupTemp(
                                        (string)dynamicList[i].Name,
                                        (string)dynamicList[i].SourcePath,
                                        (string)dynamicList[i].TargetPath,
                                        (string)dynamicList[i].Type,
                                        (string)dynamicList[i].State,
                                        (int)dynamicList[i].Progression
                                        ));
                                }
                                _mainWindow.BackupList = dummyList;
                            }
                            
                        }
                        catch (SocketException)
                        {
                        }
                    } 
                    //else
                    //{
                    //    _serverSocket.Disconnect(true);
                    //}
                }
            })
            {
                IsBackground = true
            };
            t.Start();

            return t;
        }

        public void SendData(Command command)
        {
            string json = JsonConvert.SerializeObject(command);
            byte[] buffer = Encoding.UTF8.GetBytes(json);
            _serverSocket.Send(buffer);
        }
    }
}