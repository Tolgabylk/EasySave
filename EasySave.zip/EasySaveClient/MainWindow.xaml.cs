﻿using EasySaveClient.Models;
using EasySaveGraphic.Utils;
using System.Collections.Generic;
using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;

namespace EasySaveClient
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window, INotifyPropertyChanged
    {
        private string _socketName;
        public string SocketName
        {
            get { return _socketName; }
            set
            {
                if (_socketName != value)
                {
                    _socketName = value;
                    OnPropertyChanged("SocketName");
                }
            }
        }

        private List<BackupTemp> _backupList;
        public List<BackupTemp> BackupList
        {
            get { return _backupList; }
            set
            {
                if (_backupList != value)
                {
                    _backupList = value;
                    OnPropertyChanged("BackupList");
                }
            }
        }

        private RemoteClient _remoteClient;

        public MainWindow()
        {
            InitializeComponent();
            DataContext = this;
            _remoteClient = new RemoteClient("127.0.0.1", 9050, this);
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        private void PlayButton_Click(object sender, RoutedEventArgs e)
        {
            Button b = sender as Button;
            if (_backupList[(int)b.Tag].State == "PAUSE") _remoteClient.SendData(new Command((int)b.Tag, 3));
            else _remoteClient.SendData(new Command((int)b.Tag, 1));
        }

        private void PauseButton_Click(object sender, RoutedEventArgs e)
        {
            Button b = sender as Button;
            _remoteClient.SendData(new Command((int)b.Tag, 2));
        }

        private void StopButton_Click(object sender, RoutedEventArgs e)
        {
            Button b = sender as Button;
            _remoteClient.SendData(new Command((int)b.Tag, 4));
        }
    }




}