﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EasySaveClient.Models
{
    public class Command
    {
        public int Id { get; set; }
        public int Type { get; set; }

        public Command(int id, int type)
        {
            Id = id;
            Type = type;
        }
    }
}
