﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EasySaveClient.Models
{
    public class BackupTemp
    {
        public string Name { get; set; }
        public string SourcePath { get; set; }
        public string TargetPath { get; set; }
        public string Type { get; set; }
        public string State { get; set; }
        public int Progression { get; set; }

        public BackupTemp(string name, string sourcePath, string targetPath, string type, string state, int progression)
        {
            Name = name;
            SourcePath = sourcePath;
            TargetPath = targetPath;
            Type = type;
            State = state;
            Progression = progression;
        }
    }
}
